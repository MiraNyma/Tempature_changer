<html lang="fin">
<head>
<script>
let x=0;
let y=0;
</script>
    <link rel="stylesheet" type="text/css" href="Styling.css" />
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tempchange</title>
</head>
<body>
    <div class="opacity">
    <h1>Lämpömuunnin</h1>
    <h2> Etätyö 1-4.8.2023</h2>
    <h3>Vko 31</h3>
    </div>
    <div id = "leftbox">

    </div>
    <div  id = "middlebox">
        <h4>Valitse indeksi mitä muuttaa &#8634; painikkella, valitse arvo ja paina laske</h4>
        <form action="index.php" method="get">
            <div class="form">
                Celsius: <input type="number" id="Celsius" name="Celsius" value=0 disabled> 
                Fahrenheit: <input type="number" id="faren" name="faren" value=0  disabled>
            </div>
            <div class="form">
                Kelvin: <input type="number" id="Kelvin" name="Kelvin" value=0  disabled>
                Rankine: <input type="number" id="Rankine" name="Rankine" value=0  disabled>
            </div>
            <br>
        <input type="Button" value="Laske" name="no" onclick="Transfer()">
        <input type="Button" value="&#8634;" onclick="ChangeValue()">
        <p><b>Tulos: </b></p>
        <!-- Container where the value will come out !-->
        <div id='container'>
            <p>
               
            </p>
        </div>
    <!-- Lets make a form where user can put the tempature they want to change !-->
        </form>
    </div>
    <div id = "rightbox">

    </div>

    <script>
        function Transfer(){
            //Here you count the the change in the tempatures, if the box is the active
            const Celsiusinbox = document.getElementById('Celsius');
            if (!Celsiusinbox.disabled){

                document.getElementById('container').innerHTML = "";   
                var CelsiusInv = document.getElementById("Celsius").value * 33.8 + " °F ";
                var CelsiusInv2 = document.getElementById("Celsius").value * 274.15  + " K ";
                var CelsiusInv3 = document.getElementById("Celsius").value * 493.47  + " °R ";
                let ele = document.getElementById('container');
                ele.innerHTML += CelsiusInv + CelsiusInv2 + CelsiusInv3;
            }
           
            const farenheitinbox = document.getElementById('faren');
            if (!farenheitinbox.disabled){

                document.getElementById('container').innerHTML = "";   
                var FarenInv = document.getElementById("faren").value * -17.2222222 + " °C " ;
                var FarenInv3 = document.getElementById("faren").value * 460.67 + " °R ";
                var FarenInv2 = document.getElementById("faren").value * 255.927778  + " K ";
                
                let ele = document.getElementById('container');
                ele.innerHTML += FarenInv + FarenInv2 + FarenInv3;
            }
            const Kelvininbox = document.getElementById('Kelvin');
            if (!Kelvininbox.disabled){

                document.getElementById('container').innerHTML = "";   
                var KelvinInv = document.getElementById("Kelvin").value * -272.15+ " °C ";
                var KelvinInv2 = document.getElementById("Kelvin").value * -457.87+ " °F ";
                var KelvinInv3 = document.getElementById("Kelvin").value * 1.8  + " °R ";
                
                let ele = document.getElementById('container');
                ele.innerHTML += KelvinInv + KelvinInv2 + KelvinInv3;
            }
            const Rankineinbox = document.getElementById('Rankine');
            if (!Rankineinbox.disabled){

                document.getElementById('container').innerHTML = "";   
                var RakineInv = document.getElementById("Rankine").value * -272.594444 + " °C ";
                var RakineInv2 = document.getElementById("Rankine").value * -458.67 + " °F ";
                var RakineInv3 = document.getElementById("Rankine").value * 0.555555556  + " °K ";
                
                let ele = document.getElementById('container');
                ele.innerHTML += RakineInv + RakineInv2 + RakineInv3;
            }
        }
    </script>
   
    
               
    <script>
        function ChangeValue(){
            //Here we change which box is active
            switch(x){
                case 0:
                var empty = document.getElementById("Rankine").value;
                document.getElementById("Celsius").disabled = false;
                document.getElementById("faren").disabled = true;
                document.getElementById("Kelvin").disabled = true;
                document.getElementById("Rankine").disabled = true;
                empty=0;
                x=1;
                x=y+x;
                break;
                case 1:
                var empty = document.getElementById("Celsius").value;
                document.getElementById("faren").disabled = false;
                document.getElementById("Celsius").disabled = true;
                document.getElementById("Kelvin").disabled = true;
                document.getElementById("Rankine").disabled = true;
                empty=0;
                x=2;
                x=y+x;
                break;
                case 2:
                var empty = document.getElementById("faren").value;
                document.getElementById("faren").disabled = true;
                document.getElementById("Celsius").disabled = true;
                document.getElementById("Kelvin").disabled = false;
                document.getElementById("Rankine").disabled = true;
                empty=0;
                x=3;
                x=y+x;
                break;
                case 3:
                var empty = document.getElementById("Kelvin").value;
                document.getElementById("faren").disabled = true;
                document.getElementById("Celsius").disabled = true;
                document.getElementById("Kelvin").disabled = true;
                document.getElementById("Rankine").disabled = false;
                empty=0;
                x=0;
                x=y+x;
                break;
                default: 
                    x=0;
                break
            } 
        }
    </script>
</body>
</html>